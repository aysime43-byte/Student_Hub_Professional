const { app, BrowserWindow, session } = require('electron');
const path = require('path');
function createWindow() {
  const win = new BrowserWindow({ width: 1440, height: 920, minWidth: 900, minHeight: 650, autoHideMenuBar: true, backgroundColor: '#f3f6fb', webPreferences: { contextIsolation: true, nodeIntegration: false } });
  win.loadFile(path.join(__dirname, '..', 'index.html'));
}
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => callback(permission === 'media'));
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
